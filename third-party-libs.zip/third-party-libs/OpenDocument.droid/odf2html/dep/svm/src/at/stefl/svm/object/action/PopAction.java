package at.stefl.svm.object.action;

public class PopAction extends EmptyActionObject {
    
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("PopAction []");
        return builder.toString();
    }
    
}