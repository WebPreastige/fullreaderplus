package at.stefl.svm.object.action;

public class TextLineColorAction extends SetableColorAction {
    
}