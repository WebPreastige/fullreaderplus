package at.stefl.svm.object.action;

public class OverLineColorAction extends ColorAction {
    
}