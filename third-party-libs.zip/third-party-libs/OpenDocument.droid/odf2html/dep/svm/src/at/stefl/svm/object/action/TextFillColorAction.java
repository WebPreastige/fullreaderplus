package at.stefl.svm.object.action;

public class TextFillColorAction extends ColorAction {
    
}