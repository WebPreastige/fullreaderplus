package at.stefl.svm.object.action;

public class FillColorAction extends SetableColorAction {
    
}