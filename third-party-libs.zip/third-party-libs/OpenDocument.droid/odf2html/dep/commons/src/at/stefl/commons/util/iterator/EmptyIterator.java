package at.stefl.commons.util.iterator;

public class EmptyIterator<E> extends AbstractIterator<E> {
    
}