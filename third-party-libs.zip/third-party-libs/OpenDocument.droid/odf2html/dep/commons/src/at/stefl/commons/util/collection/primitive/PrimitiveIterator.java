package at.stefl.commons.util.collection.primitive;

import java.util.Iterator;

public interface PrimitiveIterator<E> extends Iterator<E> {
    
}