package at.stefl.commons.util.collection.primitive;

import java.util.Set;

public interface PrimitiveSet<E> extends Set<E>, PrimitiveCollection<E> {
    
}