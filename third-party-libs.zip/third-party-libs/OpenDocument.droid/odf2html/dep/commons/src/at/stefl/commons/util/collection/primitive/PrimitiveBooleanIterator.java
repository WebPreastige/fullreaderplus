package at.stefl.commons.util.collection.primitive;

public interface PrimitiveBooleanIterator extends PrimitiveIterator<Boolean> {
    
    public boolean nextPrimitive();
    
}