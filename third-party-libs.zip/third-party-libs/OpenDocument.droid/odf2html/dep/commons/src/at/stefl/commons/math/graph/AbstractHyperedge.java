package at.stefl.commons.math.graph;

public abstract class AbstractHyperedge extends AbstractEdge implements
        Hyperedge {
    
}