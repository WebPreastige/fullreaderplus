package at.stefl.commons.util.collection.primitive;

public interface PrimitiveBooleanSet extends PrimitiveSet<Boolean>,
        PrimitiveBooleanCollection {
    
}